﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Tekla.Structures.Model;
using Tekla.Structures.Geometry3d;
using Point = Tekla.Structures.Geometry3d.Point;
using Tekla.Structures.Model.UI;
using Tekla.Structures.Datatype;
using Line = Tekla.Structures.Geometry3d.Line;
using Color = Tekla.Structures.Model.UI.Color;
using System.Collections;

namespace OPerationsThroughAPI
{
    public partial class Form1 : Form
    {
        #region Properties
        public Model Model { get; set; } = new Model();
        public Picker Picker { get; set; } = new Picker();

        public GraphicsDrawer GraphicsDrawer { get; set; } = new GraphicsDrawer();
        public Point P1 { get; set; } = new Point();
        public Point P2 { get; set; } = new Point();
        public Point P3 { get; set; } = new Point();
        public Point P4 { get; set; } = new Point();
        public Point P5 { get; set; } = new Point();
        public Point P6 { get; set; } = new Point();
        #endregion

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        #region ContourPlate
        private void ContourPlate_Click(object sender, EventArgs e)
        {
            //Point pickPoint1 = Picker.PickPoint("Pick Points", P1);
            //Point pickPoint2 = Picker.PickPoint("Pick Points", P2);
            //Point pickPoint3 = Picker.PickPoint("Pick Points", P3);
            //Point pickPoint4 = Picker.PickPoint("Pick Points", P4);
            //Point pickPoint5 = Picker.PickPoint("Pick Points", P5);
            //Point pickPoint6 = Picker.PickPoint("Pick Points", P6);
            ArrayList points1 =  Picker.PickPoints(Picker.PickPointEnum.PICK_POLYGON);
            List<Point> points = new List<Point>();
            foreach (Point item in points1)
            {
                points.Add(item);
            }

            //List<Point> points = new List<Point>
            //{
            //    pickPoint1, pickPoint2, pickPoint3, pickPoint4, pickPoint5, pickPoint6
            //};

            


            Point centroid = CalculateCentroid(points);
            ControlPoint point = new ControlPoint(centroid);
            point.Insert();
            GraphicsDrawer.DrawText(centroid, "centroid", new Tekla.Structures.Model.UI.Color(1, 0, 0));
            Model.CommitChanges();


            // Passing line through cenroid and points


            foreach (var item in points)
            {
                LineSegment line = new LineSegment(centroid, item);
                GraphicsDrawer.DrawLineSegment(line, new Tekla.Structures.Model.UI.Color(1, 0, 0));
            }
            /*LineSegment line1 = new LineSegment(centroid, pickPoint1);
            GraphicsDrawer.DrawLineSegment(line1, new Tekla.Structures.Model.UI.Color(1, 0, 0));

            LineSegment line2 = new LineSegment(centroid, pickPoint2);
            GraphicsDrawer.DrawLineSegment(line2, new Tekla.Structures.Model.UI.Color(1, 0, 0));

            LineSegment line3 = new LineSegment(centroid, pickPoint3);
            GraphicsDrawer.DrawLineSegment(line3, new Tekla.Structures.Model.UI.Color(1, 0, 0));

            LineSegment line4 = new LineSegment(centroid, pickPoint4);
            GraphicsDrawer.DrawLineSegment(line4, new Tekla.Structures.Model.UI.Color(1, 0, 0));

            LineSegment line5 = new LineSegment(centroid, pickPoint5);
            GraphicsDrawer.DrawLineSegment(line5, new Tekla.Structures.Model.UI.Color(1, 0, 0));

            LineSegment line6 = new LineSegment(centroid, pickPoint6);
            GraphicsDrawer.DrawLineSegment(line6, new Tekla.Structures.Model.UI.Color(1, 0, 0));*/




            CoordinateSystem cs = new CoordinateSystem(centroid, new Vector(1, 0, 0), new Vector(0, 1, 0));

            TransformationPlane transformationPlane = new TransformationPlane(cs);
            Model.GetWorkPlaneHandler().SetCurrentTransformationPlane(transformationPlane);
            CoordinateSystem setCoordinateSystem = new CoordinateSystem();

            ViewHandler.RedrawWorkplane();
            DrawCoordinateSystem(new CoordinateSystem(), "Org");

            TransformationPlane transformationPlane1 = new TransformationPlane(setCoordinateSystem);
            Matrix matrix = transformationPlane1.TransformationMatrixToLocal;
            List<Point> trPoints = new List<Point>();

            foreach (var item in points)
            {
                Point trpickPoint = matrix.Transform(new Point(item.X, item.Y));
                trPoints.Add(trpickPoint);
            }
            //Point trpickPoint1 = matrix.Transform(new Point(pickPoint1.X, pickPoint1.Y));
            //Point trpickPoint2 = matrix.Transform(new Point(pickPoint2.X, pickPoint2.Y));
            //Point trpickPoint3 = matrix.Transform(new Point(pickPoint3.X, pickPoint3.Y));
            //Point trpickPoint4 = matrix.Transform(new Point(pickPoint4.X, pickPoint4.Y));
            //Point trpickPoint5 = matrix.Transform(new Point(pickPoint5.X, pickPoint5.Y));
            //Point trpickPoint6 = matrix.Transform(new Point(pickPoint6.X, pickPoint6.Y));

            //List<Point> trPoints = new List<Point>
            //{
            //    trpickPoint1, trpickPoint2, trpickPoint3,  trpickPoint4, trpickPoint5, trpickPoint6
            //};

            var tupleList = new List<(Point, double)>();

            foreach (var trPoint in trPoints)
            {
                var angle = Math.Atan2(trPoint.X, trPoint.Y);
                tupleList.Add((trPoint, angle));
            }

            tupleList = tupleList.OrderBy(x => x.Item2).ToList();

            int ctr = 1;
            List<Point> pointList = new List<Point>();
            foreach (var tuple in tupleList)
            {
                new GraphicsDrawer().DrawText(tuple.Item1, "Point-" + ctr++, new Color());
                pointList.Add(tuple.Item1);
            }
            ContourPlate CountourPlate = new ContourPlate();
            foreach (var tuple in pointList)
            {
                CountourPlate.AddContourPoint(new ContourPoint(tuple, null));
            }


            
            
            //ContourPoint CountourPlatePoint2 = new ContourPoint(new Point(),);
            //ContourPoint CountourPlatePoint3 = new ContourPoint(new Point());
            //ContourPoint CountourPlatePoint4 = new ContourPoint(new Point());
            //ContourPoint CountourPlatePoint5 = new ContourPoint(new Point());
            //ContourPoint CountourPlatePoint6 = new ContourPoint(new Point());

            
            //CountourPlate.AddContourPoint(CountourPlatePoint2);
            //CountourPlate.AddContourPoint(CountourPlatePoint3);
            //CountourPlate.AddContourPoint(CountourPlatePoint4);
            //CountourPlate.AddContourPoint(CountourPlatePoint5);
            //CountourPlate.AddContourPoint(CountourPlatePoint6);
            CountourPlate.Profile.ProfileString = "PLT304.8";
            CountourPlate.Material.MaterialString = "3000";
            CountourPlate.Position.Depth = Position.DepthEnum.BEHIND;
            CountourPlate.Insert();
            Model.CommitChanges();


            SetGlobalandStoreOriginal();
            Model.CommitChanges();

        }

        private Point CalculateCentroid(List<Point> points)
        {

            double sumX = 0.0;
            double sumY = 0.0;
            double sumZ = 0.0;

            foreach (Point point in points)
            {
                sumX += point.X;
                sumY += point.Y;
                sumZ += point.Z;
            }
            return new Point(sumX / points.Count(), sumY / points.Count(), sumZ / points.Count());
        }

        #endregion



        #region Support Methods
        private void DrawCoordinateSystem(CoordinateSystem coordinateSystem, string v)
        {
            double lengthFoot = 2.0;
            Tekla.Structures.Model.UI.GraphicsDrawer graphicsDrawer = new GraphicsDrawer();

            Point X = coordinateSystem.Origin + coordinateSystem.AxisX.GetNormal() * lengthFoot * 12 * 25.4;
            Point Y = coordinateSystem.Origin + coordinateSystem.AxisY.GetNormal() * lengthFoot * 12 * 25.4;
            Point Z = coordinateSystem.Origin + coordinateSystem.AxisX.Cross(coordinateSystem.AxisY).GetNormal() * lengthFoot * 12 * 25.4;

            graphicsDrawer.DrawText(coordinateSystem.Origin, "Origin", new Color());
            graphicsDrawer.DrawText(X, "X", new Color(1, 0, 0));
            graphicsDrawer.DrawText(Y, "Y", new Color(0, 1, 0));
            graphicsDrawer.DrawText(Z, "Z", new Color(0, 0, 1));

            graphicsDrawer.DrawLineSegment(new LineSegment(coordinateSystem.Origin, X), new Color(1, 0, 0));
            graphicsDrawer.DrawLineSegment(new LineSegment(coordinateSystem.Origin, Y), new Color(0, 1, 0));
            graphicsDrawer.DrawLineSegment(new LineSegment(coordinateSystem.Origin, Z), new Color(0, 0, 1));
        }

        private TransformationPlane SetGlobalandStoreOriginal()
        {
            WorkPlaneHandler myWorkPlaneHandler = Model.GetWorkPlaneHandler();
            TransformationPlane myTransformationPlane = myWorkPlaneHandler.GetCurrentTransformationPlane();

            // Create a new trasnformation plane based on the part coordinate system
            TransformationPlane newTSPlane = new TransformationPlane();

            // Set current transformation plane to the part plane
            Model.GetWorkPlaneHandler().SetCurrentTransformationPlane(newTSPlane);

            Model.CommitChanges();
            return myTransformationPlane;
        }
        #endregion
    }
}
